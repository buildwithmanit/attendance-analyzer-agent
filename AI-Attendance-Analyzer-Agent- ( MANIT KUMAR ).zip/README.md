# AI Attendance Analyzer Agent

This project is an AI-powered autonomous attendance agent that processes daily logs, identifies presence status, and automatically updates reports.