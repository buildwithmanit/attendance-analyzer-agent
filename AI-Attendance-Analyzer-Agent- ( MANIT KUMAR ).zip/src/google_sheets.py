import gspread
from oauth2client.service_account import ServiceAccountCredentials

def sync_to_google_sheet(df, sheet_name="Daily Attendance"):
    scope = ["https://spreadsheets.google.com/feeds", "https://www.googleapis.com/auth/drive"]
    creds = ServiceAccountCredentials.from_json_keyfile_name("credentials.json", scope)
    client = gspread.authorize(creds)

    sheet = client.open("AI Attendance Log").worksheet(sheet_name)
    sheet.clear()

    sheet.insert_row(df.columns.tolist(), 1)
    for index, row in df.iterrows():
        sheet.insert_row(row.tolist(), index + 2)
