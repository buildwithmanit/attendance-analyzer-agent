import pandas as pd
from datetime import datetime
import os

INPUT_PATH = "data/input_logs.csv"
OUTPUT_PATH = "output/attendance_report.xlsx"
LATE_THRESHOLD = datetime.strptime("09:30", "%H:%M")

def classify_time(checkin_time):
    if pd.isna(checkin_time):
        return "Absent", "No Check-In"
    try:
        check_time = datetime.strptime(checkin_time.strip(), "%I:%M %p")
        if check_time <= LATE_THRESHOLD:
            return "Present", "On Time"
        else:
            return "Late", "Checked in Late"
    except ValueError:
        return "Absent", "Invalid Time Format"

def process_attendance():
    if not os.path.exists(INPUT_PATH):
        raise FileNotFoundError(f"⚠️ Log file not found at: {INPUT_PATH}")

    df = pd.read_csv(INPUT_PATH)

    statuses = [classify_time(time) for time in df["Check-In Time"]]
    df["Status"] = [s[0] for s in statuses]
    df["Remarks"] = [s[1] for s in statuses]

    os.makedirs("output", exist_ok=True)
    df.to_excel(OUTPUT_PATH, index=False)
    print("✅ Attendance processed successfully. Output saved at:", OUTPUT_PATH)
