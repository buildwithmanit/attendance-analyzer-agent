import face_recognition
import cv2
import os
from datetime import datetime

known_face_encodings = []
known_face_names = []

# Load known images from 'faces/' directory
for filename in os.listdir('faces'):
    if filename.endswith(".jpg"):
        image = face_recognition.load_image_file(f"faces/{filename}")
        encoding = face_recognition.face_encodings(image)[0]
        known_face_encodings.append(encoding)
        known_face_names.append(filename.split(".")[0].replace("_", " "))

video_capture = cv2.VideoCapture(0)
checked_in = {}

while True:
    ret, frame = video_capture.read()
    rgb_frame = frame[:, :, ::-1]
    face_locations = face_recognition.face_locations(rgb_frame)
    face_encodings = face_recognition.face_encodings(rgb_frame, face_locations)

    for face_encoding in face_encodings:
        matches = face_recognition.compare_faces(known_face_encodings, face_encoding)
        name = "Unknown"

        if True in matches:
            first_match_index = matches.index(True)
            name = known_face_names[first_match_index]

            if name not in checked_in:
                checked_in[name] = datetime.now().strftime("%I:%M %p")
                print(f"{name} checked in at {checked_in[name]}")

    cv2.imshow("Camera", frame)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

video_capture.release()
cv2.destroyAllWindows()
