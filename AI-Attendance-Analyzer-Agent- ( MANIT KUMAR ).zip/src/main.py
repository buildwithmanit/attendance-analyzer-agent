from src.processor import process_attendance
from src.scheduler import schedule_job
from src.utils import ensure_dirs
import logging

logging.basicConfig(filename='logs/system.log', level=logging.INFO, format='%(asctime)s %(message)s')

if __name__ == "__main__":
    ensure_dirs()
    logging.info("🟢 Starting Attendance Analyzer Agent...")
    schedule_job(process_attendance)
