import schedule
import time
import logging

def schedule_job(task_function):
    schedule.every().day.at("10:00").do(task_function)
    logging.info("⏰ Task scheduled for 10:00 AM daily.")
    while True:
        schedule.run_pending()
        time.sleep(60)
